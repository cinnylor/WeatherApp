package com.example.weatherapp.data

data class CurrentConditions(
    val temp: Float,
    val cityName: String
)
